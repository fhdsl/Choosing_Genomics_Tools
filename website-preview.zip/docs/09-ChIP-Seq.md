


# ChIP-Seq

## Learning Objectives

![](resources/images/09-ChIP-Seq_files/figure-docx//1YwxXy2rnUgbx_7B7ENH9wpDX-j6JpJz6lGVzOkjo0qY_g12890ae15d7_0_61.png){width=100%}

## What are the goals of ChIP-Seq analysis?

The goal of ChIP-Seq is to....

![](resources/images/09-ChIP-Seq_files/figure-docx//1YwxXy2rnUgbx_7B7ENH9wpDX-j6JpJz6lGVzOkjo0qY_g14492c87338_0_18.png){width=100%}

## ChIP-Seq general workflow overview

## ChIP-Seq data **strengths**:

## ChIP-Seq data **limitations**:

## ChIP-Seq data considerations

## ChiP-seq analysis tools

## More resources about ChiP-seq data
